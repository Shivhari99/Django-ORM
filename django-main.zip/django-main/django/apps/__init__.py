from .config import AppConfig
from .registry import apps

__all__ = ['AppConfig', 'apps']
